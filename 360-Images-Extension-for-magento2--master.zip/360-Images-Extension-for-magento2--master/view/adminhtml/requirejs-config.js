
var config = {
    map: {
        '*': {
            image360:        'Codilar_Image360/js/script',
            image360Gallery: 'Codilar_Image360/js/image360-gallery'
        }
    }
};
